using System;
using System.Threading;
using System.Collections.Generic;
using System.Collections.Concurrent;
using br.ufc.mdcc.hpcshelf.gust.graph.Vertex;
using br.ufc.mdcc.common.impl.IteratorImpl;
using br.ufc.mdcc.common.impl.KVPairImpl;
using br.ufc.mdcc.common.Iterator;
using br.ufc.mdcc.common.impl.IteratorImpl;
using br.ufc.mdcc.common.KVPair;
using br.ufc.mdcc.hpcshelf.gust.graph.InputFormat;
using br.ufc.mdcc.hpcshelf.gust.graph.impl.InputFormatImpl;
using br.ufc.mdcc.common.graph.InterfacesOf;
using br.ufc.mdcc.common.graph.GraphImpl;
using br.ufc.mdcc.common.graph.Common;
using br.ufc.mdcc.common.graph.Algorithm;
using br.ufc.mdcc.hpcshelf.gust.example.pgr.DataPGRANK;
using br.ufc.mdcc.hpcshelf.gust.example.pgr.DataPGRANKImpl;
using System.Linq;
using MPI;
using br.ufc.mdcc.hpcshelf.gust.graph.VertexBasic;
using br.ufc.mdcc.hpcshelf.gust.graph.impl.VertexBasicImpl;

namespace br.ufc.mdcc.hpcshelf.gust.example.tc.TriangleCountImpl {
	public class IPGRANKMPI : BaseIPGRANKMPI, APPMPI {
		private long[] t0 = new long[4];
		private long[] t1 = new long[4];
		private string[] stime = new string[4];
		private bool sair = false;
		private MPI.Environment mpi = null;
		private Intracommunicator worldcomm = null;
		private int node = 0; public int NODE{ get { return node; } set { node = (int)value; } }
		private int SIZE = 0;
		private double soma_global = 0.0f;
		private int superstep = 0;

		private int[] partition = null;
		private bool[]  partition_own = null;
		private int partition_size = 0;
		private double nothing_outgoing = 0;
		private double sum_nothings = 0.0f;
		private int partid = 0;
		private int MAX_ITERATION = 29;
		IDictionary<int, double> before = new Dictionary<int, double>();
		private IDictionary<int, double>[] messages = null;
		private IDictionary<int, ICollection<int>> cache = new Dictionary<int, ICollection<int>>();
		public bool isGhost(int v){ return !partition_own[this.partition [v - 1]]; }

		public int Superstep { get { return this.superstep; } set { this.superstep = value; } }
		public void gcsp(){
			IInputFormatInstance i = new IInputFormatInstanceImpl ();
			i.PARTITION_SIZE = SIZE;
			IDictionary<int, IInputFormatInstance> bins = i.extractBins (this.CFG.PATH);
			foreach (KeyValuePair<int, IInputFormatInstance> kv in bins) {
				IIteratorInstance<IKVPair<IVertexBasic,IDataPGRANK>> output_value_instance = (IIteratorInstance<IKVPair<IVertexBasic,IDataPGRANK>>)Output_messages.Instance;
				IKVPairInstance<IVertexBasic,IDataPGRANK> ITEM = (IKVPairInstance<IVertexBasic,IDataPGRANK>)Output_messages.createItem ();
				((IVertexBasicInstance)ITEM.Key).Id = kv.Key;
				((IVertexBasicInstance)ITEM.Key).PId = (byte) kv.Key;
				((IDataPGRANKInstance)ITEM.Value).Value = kv.Value;
				output_value_instance.put (ITEM);
				this.partition_size = kv.Value.PARTITION_SIZE;
				this.partition = kv.Value.PartitionTABLE;
			}
		}
		#region Construtor Start
		public IPGRANKMPI(Config cfg, string[] args){
			this.CFG = cfg;
			mpi = new MPI.Environment (ref args);
			worldcomm = Communicator.world;
			SIZE = worldcomm.Size;
			NODE = worldcomm.Rank;
			p_size = SIZE;
			object[] buffer = new object[SIZE];
			double sum = 0; double destaque = 0;

			if (NODE == 0) {
				Console.WriteLine (cfg.ToString ());
				this.gcsp ();
			}
			this.partition_size = SIZE;
			do { 
				this.time (0); this.close (); stime[0] = this.time (0,true); 
				this.time (1); this.send_receive (); stime[1] = this.time (1,true); 
				this.time (3); gust0 ();  stime[3] = this.time (3,true); 
				Console.WriteLine ("Ite "+superstep+": close("+NODE+") "+stime[0]+" - send_receive("+NODE+") "+stime[1]+" - call_pull("+NODE+") "+stime[2]+" - gust0("+NODE+") "+stime[3]);
				superstep++;
			} while (superstep <= MAX_ITERATION);

			IIteratorInstance<IKVPair<IVertexBasic,IDataPGRANK>> outputs = (IIteratorInstance<IKVPair<IVertexBasic,IDataPGRANK>>)Output_messages.Instance;
			object o;
			outputs.finish ();
			while (outputs.fetch_next (out o)) {
				IKVPairInstance<IVertexBasic,IDataPGRANK> kv = (IKVPairInstance<IVertexBasic,IDataPGRANK>)o;
				IVertexBasicInstance KEY = (IVertexBasicInstance)kv.Key;
				IDataPGRANKInstance VALUE = (IDataPGRANKInstance)kv.Value;
				foreach (KeyValuePair<int,double> KV in VALUE.Ranks) {
					if (KV.Key == 151069)
						destaque = KV.Value;
					sum += KV.Value;
				}
			}

			double rsum = worldcomm.Reduce<double> (sum, MPI.Operation<double>.Add, 0);
			double rdestaque = worldcomm.Reduce<double> (destaque, MPI.Operation<double>.Add, 0);
			if (NODE == 0)
				Console.WriteLine ("Emite sum: " + rsum + " Destaque: " + rdestaque);
			worldcomm.Barrier ();
			mpi.Dispose ();
		}
		public string time(int p, bool i = false){
			if(!i) t0[p] = (long)(DateTime.UtcNow - (new DateTime (1970, 1, 1, 0, 0, 0, DateTimeKind.Utc))).TotalMilliseconds;
			if(i) t1[p] = (long)(DateTime.UtcNow - (new DateTime (1970, 1, 1, 0, 0, 0, DateTimeKind.Utc))).TotalMilliseconds;
			return ((t1[p] - t0[p])+"");
		}
		#endregion

		#region Create Directed Graph Weight
		public void graph_creator(IInputFormatInstance gif){
			partition = gif.PartitionTABLE; 
			partition_size = gif.PARTITION_SIZE; 
			this.partid = gif.PARTID;
			if(partition_own==null)
				partition_own = new bool[partition_size];
			if (messages == null) {
				messages = new Dictionary<int, double>[partition_size];
			}
			for (int i = 0; i < gif.ESIZE;i++) {
				int s = gif.Source [i];
				int t = gif.Target [i];
				g.addVertex (s);
				g.addVertex (t);
				if(s!=t) g.noSafeAdd (s, t);
			} Console.WriteLine ("Graph Creator: " + gif.PARTID);
			partition_own[gif.PARTID] = true;
			gif.Clear ();
		}
		#endregion

		#region Algorithm implementation
		public void startup() {
			before = new Dictionary<int, double>(g.countV()+1);
			messages = new Dictionary<int, double>[partition_size];
			for (int i = 0; i < partition_size; i++) messages[i] = new Dictionary<int, double> ();

			ICollection<int> vertices = g.vertexSet ();
			foreach (int v in vertices) {
				if (!messages [partition [v - 1]].ContainsKey (v)) messages [partition [v - 1]] [v] = 0.0f;
				if (!isGhost (v)) {
					bool any = false;
					before [v] = 0.0f;
					ICollection<int> vneighbors = g.outgoingVertexOf (v);
					if (!cache.ContainsKey (v))
						cache [v] = vneighbors;
					foreach(int n in vneighbors) {
						any = true;
						if (!messages [partition [n - 1]].ContainsKey (n)) messages [partition [n - 1]] [n] = 0.0f;
						messages [partition [n - 1]] [n] += 1.0f / g.outDegreeOf (v);
					}
					if (!any) nothing_outgoing+=1.0f;
				}
			}
		}
		public void input_messages() {
			IKVPairInstance<IVertexBasic,IIterator<IDataPGRANK>> input_values_instance = (IKVPairInstance<IVertexBasic,IIterator<IDataPGRANK>>)Input_values.Instance;
			IIteratorInstance<IDataPGRANK> ivalues = (IIteratorInstance<IDataPGRANK>)input_values_instance.Value;

			object o;
			while (ivalues.fetch_next (out o)) {
				IDataPGRANKInstance VALUE = (IDataPGRANKInstance)o;
				if (this.Superstep == 0)
					this.graph_creator ((IInputFormatInstance)VALUE.Value);
				else {
					double[] bin = (double[])VALUE.Value;
					if (bin.Count () > 0) {
						for (int k = 1; k <= partition.Count (); k++) {
							double rank_value = bin [k];
							if (rank_value > 0) {
								int rank_key = k;
								messages [partition [rank_key - 1]] [rank_key] += rank_value; // foreach (KeyValuePair<int, double> kv in VALUE.Ranks) // messages [partition [kv.Key - 1]] [kv.Key] += kv.Value; // sum_nothings += VALUE.Slice;
							}
						}
					}
					sum_nothings += VALUE.Slice;
				}
			}
		}
		public void gust0(){
			if (this.Superstep == 0)
				this.startup ();
			else {
				ICollection<int> vertices = g.vertexSet ();
				foreach (int v in vertices)
					if (!isGhost (v)) {
						before [v] = messages [partition [v - 1]] [v] + sum_nothings - before [v];
						messages [partition [v - 1]] [v] = before [v];
					}
				if (this.Superstep < MAX_ITERATION)
					foreach (int v in vertices) {
						if (!isGhost (v)) {
							bool any = false;
							ICollection<int> vneighbors = cache [v];//g.iteratorOutgoingVertexOf (v);
							foreach (int n in vneighbors) { //while(vneighbors.MoveNext()){ int n = vneighbors.Current;
								any = true;
								if (!messages [partition [n - 1]].ContainsKey (n))
									messages [partition [n - 1]] [n] = 0.0f;
								messages [partition [n - 1]] [n] += before [v] / g.outDegreeOf (v);
							}
							if (!any)
								nothing_outgoing += before [v];
						}
					}
			}
			emite ();
		}
		private void emite(){
			IIteratorInstance<IKVPair<IVertexBasic,IDataPGRANK>> output_value_instance = (IIteratorInstance<IKVPair<IVertexBasic,IDataPGRANK>>)Output_messages.Instance;
			if (this.Superstep == MAX_ITERATION) {
				IKVPairInstance<IVertexBasic,IDataPGRANK> ITEM = (IKVPairInstance<IVertexBasic,IDataPGRANK>)Output_messages.createItem ();
				((IVertexBasicInstance)ITEM.Key).Id = this.partid;
				((IVertexBasicInstance)ITEM.Key).PId = (byte)this.partid;
				((IDataPGRANKInstance)ITEM.Value).Ranks = messages [((IVertexBasicInstance)ITEM.Key).PId];
				output_value_instance.put (ITEM);
				output_value_instance.finish ();
			} else {
				for (int i = 0; i < partition_size; i++) {
					IKVPairInstance<IVertexBasic,IDataPGRANK> ITEM = (IKVPairInstance<IVertexBasic,IDataPGRANK>)Output_messages.createItem ();
					((IVertexBasicInstance)ITEM.Key).Id = i;
					((IVertexBasicInstance)ITEM.Key).PId = (byte) i;
					if (partition_own [i])
						((IDataPGRANKInstance)ITEM.Value).Value = new double[0];//bin;
					else {
						KeyValuePair<int,double>[] kv = messages [i].ToArray ();
						double[] bin = new double[partition.Count()+1];
						foreach (KeyValuePair<int,double> b in kv)
							bin [b.Key] = b.Value;
						((IDataPGRANKInstance)ITEM.Value).Value = bin;
						messages [i] = new Dictionary<int, double> ();
					}
					((IDataPGRANKInstance)ITEM.Value).Slice = nothing_outgoing / ((double)partition.Length);

					output_value_instance.put (ITEM);
				}
			}
			nothing_outgoing = 0.0f;
			sum_nothings = 0.0f;
		}
		#endregion

		#region Close/get data iterations
		public void close () {
			IDictionary<object,IIteratorInstance<IDataPGRANK>> kv_cache = new Dictionary<object,IIteratorInstance<IDataPGRANK>> ();
			IIteratorInstance<IKVPair<IVertexBasic,IIterator<IDataPGRANK>>>[] ooutput_mv = new IIteratorInstance<IKVPair<IVertexBasic,IIterator<IDataPGRANK>>>[partition_size];
			for (int k = 0; k < partition_size; k++)
				ooutput_mv [k] = (IIteratorInstance<IKVPair<IVertexBasic,IIterator<IDataPGRANK>>>)OutputMV [k].Instance;

			IIteratorInstance<IKVPair<IVertexBasic,IDataPGRANK>> output_kv_emited = (IIteratorInstance<IKVPair<IVertexBasic,IDataPGRANK>>)Output_messages.Instance;
			output_kv_emited.finish ();
			object o;
			IIterator<IDataPGRANK> factory = new IIteratorImpl<IDataPGRANK> ();
			factory.Item_factory = new IDataPGRANKImpl ();

			while (output_kv_emited.fetch_next (out o)) {
				IKVPairInstance<IVertexBasic,IDataPGRANK> kv = (IKVPairInstance<IVertexBasic,IDataPGRANK>)o;
				IVertexBasicInstance chave = (IVertexBasicInstance)kv.Key;
				IIteratorInstance<IDataPGRANK> iterator = null;
				if (!kv_cache.ContainsKey (kv.Key)) {
					iterator = factory.newIteratorInstance ();
					kv_cache.Add (kv.Key, iterator);
					IKVPairInstance<IVertexBasic,IIterator<IDataPGRANK>> item = (IKVPairInstance<IVertexBasic,IIterator<IDataPGRANK>>)OutputMV [chave.PId].createItem ();
					item.Key = kv.Key;
					item.Value = iterator;
					ooutput_mv [chave.PId].put (item);
				} else
					kv_cache.TryGetValue (kv.Key, out iterator);

				iterator.put (kv.Value);
			}
			foreach (IIteratorInstance<IDataPGRANK> iterator in kv_cache.Values)
				iterator.finish ();
		}
		#endregion

		#region iterate pull
		public void call_pull () {
			this.time (2); 
			IIteratorInstance<IKVPair<IVertexBasic,IIterator<IDataPGRANK>>> output_mv = (IIteratorInstance<IKVPair<IVertexBasic,IIterator<IDataPGRANK>>>)OutputMV[NODE].Instance;
			object o;
			while (output_mv.fetch_next (out o)) {
				IKVPairInstance<IVertexBasic,IIterator<IDataPGRANK>> kv = (IKVPairInstance<IVertexBasic,IIterator<IDataPGRANK>>)o;
				Input_values.Instance = kv;
				input_messages ();
			}
			stime[2] = this.time (2,true); 
		}
		#endregion

		#region MPI send receive
		public void send_receive () {
			Thread pull = new Thread (() => call_pull ());
			RequestList requestList = new RequestList ();
			Request[] request = new Request[2];
			object o;
			for (int p = 0; p < SIZE; p++) {
				if (p != NODE) {
					object[] msn = { OutputMV [p].Instance };
					request [0] = worldcomm.ImmediateSend<object> (msn, p, 1);
					requestList.Add (request [0]);
				}
			}
			for (int p = 0; p < SIZE; p++) {
				if (p != NODE) {
					IIteratorInstance<IKVPair<IVertexBasic,IIterator<IDataPGRANK>>> x = (IIteratorInstance<IKVPair<IVertexBasic,IIterator<IDataPGRANK>>>)OutputMV [p].Instance;
					OutputMV [p].newInstance ();
				}
			}
			IIteratorInstance<IKVPair<IVertexBasic,IIterator<IDataPGRANK>>> output_mv = (IIteratorInstance<IKVPair<IVertexBasic,IIterator<IDataPGRANK>>>)OutputMV[NODE].Instance;
			pull.Start ();
			for (int p = 0; p < SIZE; p++) { 
				if (p != NODE) {
					object[] buffer = worldcomm.Receive<object[]> (p, 1);//object[] buffer = worldcomm.Receive<object[]> (MPI.Unsafe.MPI_ANY_SOURCE, 1);
					foreach (object oo in buffer) {
						if (oo != null) {
							IIteratorInstance<IKVPair<IVertexBasic,IIterator<IDataPGRANK>>> output_instance_tmp = (IIteratorInstance<IKVPair<IVertexBasic,IIterator<IDataPGRANK>>>)oo;
							output_instance_tmp.finish ();
							while (output_instance_tmp.fetch_next (out o)) {
								IKVPairInstance<IVertexBasic,IIterator<IDataPGRANK>> kv = (IKVPairInstance<IVertexBasic,IIterator<IDataPGRANK>>)o;
								output_mv.put (o);
							}
						}
					}
				}
			}
			requestList.WaitAll ();
			output_mv.finish ();
			pull.Join ();
		}
		#endregion
	}
}



