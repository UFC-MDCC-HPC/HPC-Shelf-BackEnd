#!/bin/sh
echo “Limpando Cache…”
sudo echo 3 > /proc/sys/vm/drop_caches
sudo sysctl -w vm.drop_caches=3

#sudo sysctl vm.swappiness=10

sudo swapoff -a
sudo swapon -a

cat /proc/sys/vm/swappiness

echo “Limpeza do Cache efetuada com sucesso”


