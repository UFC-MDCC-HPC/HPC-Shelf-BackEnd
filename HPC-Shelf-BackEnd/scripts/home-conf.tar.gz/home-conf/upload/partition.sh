#!/bin/sh
case $1 in 
	'')
		echo "Num partition? <metis | clear | num>"
	;;
	'metis')
		cp /opt/data/metis.part/*.* /opt/data/
	;;
	'clear')
		rm -f /opt/data/*.metis.part*
	;;
	[0-9]*)
		PART=$1
		vsize=4847571 partition_size=$PART awk 'BEGIN{for(i=0;i<ENVIRON["vsize"];i++){s=i%ENVIRON["partition_size"]; print s}}' > /opt/data/LiveJournal.e.metis.part.$PART
		vsize=1632803 partition_size=$PART awk 'BEGIN{for(i=0;i<ENVIRON["vsize"];i++){s=i%ENVIRON["partition_size"]; print s}}' > /opt/data/pokec.e.metis.part.$PART
		vsize=1696415 partition_size=$PART awk 'BEGIN{for(i=0;i<ENVIRON["vsize"];i++){s=i%ENVIRON["partition_size"]; print s}}' > /opt/data/skitter.e.metis.part.$PART
		vsize=262111 partition_size=$PART awk 'BEGIN{for(i=0;i<ENVIRON["vsize"];i++){s=i%ENVIRON["partition_size"]; print s}}' > /opt/data/amazon0302.e.metis.part.$PART
		;;
	*)
		echo "default"
esac






